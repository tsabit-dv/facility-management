<?php
$servername = "localhost";
$username = "root"; // Adjust to your DB user
$password = ""; // Adjust to your DB password
$dbname = "facility_management";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// No echo or close here
?>