// --- File: assets/php/js/main.js (Versi Final) ---

// Variabel global untuk menyimpan kategori yang sedang aktif
let currentCategory = '';

/**
 * Event listener ini akan berjalan setelah seluruh halaman HTML selesai dimuat.
 * Ini adalah tempat terbaik untuk menempatkan semua setup event listener.
 */
document.addEventListener('DOMContentLoaded', function () {
    // --- MANAJEMEN FOKUS UNTUK MODAL KATEGORI ---
    const categoryModalEl = document.getElementById('categoryModal');
    const openModalBtn = document.getElementById('openCategoryModalBtn');

    if (categoryModalEl && openModalBtn) {
        // Dengarkan event 'hidden.bs.modal'. Event ini di-trigger oleh Bootstrap
        // SETELAH modal selesai ditutup (setelah animasi selesai).
        categoryModalEl.addEventListener('hidden.bs.modal', function () {
            // Kembalikan fokus ke tombol yang membuka modal.
            // Ini akan menyelesaikan peringatan aksesibilitas.
            openModalBtn.focus();
        });
    }

    // --- EVENT LISTENER UNTUK SUBMIT FORM ---
    function handleFormSubmit(event) {
        event.preventDefault();
        const workOrderId = document.getElementById(currentCategory.toLowerCase() + 'WorkOrderId').value;
        document.getElementById('successMessage').innerText = 'Work Order #' + workOrderId + ' berhasil disimpan!';
        new bootstrap.Modal(document.getElementById('successModal')).show();
    }

    document.getElementById('cleanForm').addEventListener('submit', handleFormSubmit);
    document.getElementById('inspectionForm').addEventListener('submit', handleFormSubmit);
    document.getElementById('controlForm').addEventListener('submit', handleFormSubmit);
    document.getElementById('adHocForm').addEventListener('submit', handleFormSubmit);

    document.getElementById('finishTaskForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const workOrderId = document.getElementById('finishWorkOrderId').value;
        document.getElementById('successMessage').innerText = 'Tugas untuk Work Order #' + workOrderId + ' telah selesai!';
        const successModal = new bootstrap.Modal(document.getElementById('successModal'));
        successModal.show();
        const finishModal = bootstrap.Modal.getInstance(document.getElementById('finishTaskModal'));
        if (finishModal) {
            finishModal.hide();
        }
    });
});


// --- FUNGSI-FUNGSI UTAMA ---

// Ganti fungsi openForm yang lama dengan yang ini

function openForm(category) {
    const userRole = document.body.getAttribute('data-role');

    // Cek izin akses
    if (category === 'AdHoc' && userRole !== 'Supervisor' && userRole !== 'Admin') {
        const restrictedModal = new bootstrap.Modal(document.getElementById('restrictedModal'));
        restrictedModal.show();
        const categoryModal = bootstrap.Modal.getInstance(document.getElementById('categoryModal'));
        if (categoryModal) {
            categoryModal.hide();
        }
        return;
    }

    currentCategory = category;

    // Tutup modal pemilihan kategori
    const categoryModal = bootstrap.Modal.getInstance(document.getElementById('categoryModal'));
    if (categoryModal) {
        categoryModal.hide();
    }

    // Sembunyikan dashboard
    document.getElementById('dashboardPage').classList.add('d-none');
    
    // Temukan dan tampilkan form yang sesuai
    const formPage = document.getElementById(category.toLowerCase() + 'FormPage');
    if (formPage) {
        formPage.classList.remove('d-none');
        // --- PERBAIKAN UTAMA DI SINI ---
        // Pindahkan fokus secara langsung ke panel form yang baru ditampilkan.
        // Ini memberi tahu browser di mana fokus seharusnya berada SEKARANG,
        // sehingga tidak ada lagi fokus yang tertinggal di modal yang tertutup.
        formPage.focus();
    }
    
    // Siapkan form untuk input baru
    resetAndPrepareForm(category);
}

function openTask(workOrderId, category, status) {
    currentCategory = category;
    document.getElementById('dashboardPage').classList.add('d-none');
    const formPage = document.getElementById(category.toLowerCase() + 'FormPage');
    if (formPage) {
        formPage.classList.remove('d-none');
    }
    populateFormWithData(workOrderId, category, status);
}

function backToDashboard() {
    document.getElementById('cleanFormPage').classList.add('d-none');
    document.getElementById('inspectionFormPage').classList.add('d-none');
    document.getElementById('controlFormPage').classList.add('d-none');
    document.getElementById('adHocFormPage').classList.add('d-none');
    document.getElementById('dashboardPage').classList.remove('d-none');
}

function openFinishTask(category) {
    currentCategory = category;
    const workOrderId = document.getElementById(category.toLowerCase() + 'WorkOrderId').value;
    document.getElementById('finishWorkOrderId').value = workOrderId;
    document.getElementById('finishTaskForm').reset();
    new bootstrap.Modal(document.getElementById('finishTaskModal')).show();
}


// --- FUNGSI PEMBANTU ---

function resetAndPrepareForm(category) {
    const formId = category.toLowerCase() + 'Form';
    const formElement = document.getElementById(formId);
    if (formElement) {
        formElement.reset();
    }
    const workOrderIdInput = document.getElementById(category.toLowerCase() + 'WorkOrderId');
    if (workOrderIdInput) {
        workOrderIdInput.value = Math.floor(Math.random() * 1000) + 1;
    }
    const photoBeforeSection = document.getElementById(category.toLowerCase() + 'PhotoBeforeSection');
    if (photoBeforeSection) photoBeforeSection.classList.add('d-none');
    const finishTaskBtn = document.getElementById(category.toLowerCase() + 'FinishTaskBtn');
    if (finishTaskBtn) finishTaskBtn.classList.add('d-none');
}

function populateFormWithData(workOrderId, category, status) {
    const workOrderIdInput = document.getElementById(category.toLowerCase() + 'WorkOrderId');
    if (workOrderIdInput) workOrderIdInput.value = workOrderId;

    // ... (sisa logika simulasi data Anda tetap sama) ...
    if (category === 'Clean' && workOrderId == 1) {
        document.getElementById('clean_location').value = 'Ruang Meeting';
        document.getElementById('clean_description').value = 'Membersihkan lantai, meja, dan kaca';
    } else if (category === 'Clean' && workOrderId == 3) {
        document.getElementById('clean_location').value = 'Kantin';
        document.getElementById('clean_description').value = 'Membersihkan meja dan lantai';
    } else if (category === 'Inspection' && workOrderId == 2) {
        document.getElementById('area_inspected').value = 'Lantai 3';
        document.getElementById('inspection_notes').value = 'Lantai bersih, tetapi ada kabel longgar di lorong';
    } else if (category === 'AdHoc' && workOrderId == 4) {
        document.getElementById('adhoc_description').value = 'Mengganti lampu di tangga darurat';
    }


    const photoBeforeSection = document.getElementById(category.toLowerCase() + 'PhotoBeforeSection');
    const finishTaskBtn = document.getElementById(category.toLowerCase() + 'FinishTaskBtn');
    if (status === 'Pending' && photoBeforeSection && finishTaskBtn) {
        photoBeforeSection.classList.remove('d-none');
        finishTaskBtn.classList.remove('d-none');
    } else {
        if (photoBeforeSection) photoBeforeSection.classList.add('d-none');
        if (finishTaskBtn) finishTaskBtn.classList.add('d-none');
    }
}