<?php
session_start();

require '../backend/con.php'; 

if (isset($_SESSION['status_login']) && $_SESSION['status_login'] === true) {
    header("Location: ../index.php");
    exit;
}

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT id, username, password, name, role FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    
    if ($stmt === false) {
        die("Server error. Please try again later.");
    }
    
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $users = $result->fetch_assoc();
        
        // --- PERUBAHAN UTAMA DI SINI ---
        // Mengganti password_verify() dengan perbandingan teks biasa.
        // PERINGATAN: SANGAT TIDAK AMAN UNTUK PRODUKSI!
        if ($password === $users['password']) {
            // Jika password cocok, login berhasil
            $_SESSION['status_login'] = true;
            $_SESSION['user_id'] = $users['id'];
            $_SESSION['username'] = $users['username'];
            $_SESSION['name'] = $users['name']; 
            $_SESSION['role'] = $users['role'];

            header("Location: ../index.php");
            exit;
        } else {
            // Jika password tidak cocok
            $error_message = "Username atau password salah!";
        }
    } else {
        // Jika username tidak ditemukan
        $error_message = "Username atau password salah!";
    }
    $stmt->close();
}
// Bagian HTML di bawah ini tidak perlu diubah, jadi saya tidak menuliskannya lagi.
// Pastikan bagian HTML dari file Anda tetap ada.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Facility Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f8f9fa;
        }
        .login-card {
            max-width: 400px;
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="card login-card">
        <div class="card-body">
            <h3 class="card-title text-center mb-4">Silakan Login</h3>
            
            <?php if (!empty($error_message)): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo htmlspecialchars($error_message, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            <?php endif; ?>

            <form action="login.php" method="POST">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary">Login</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>