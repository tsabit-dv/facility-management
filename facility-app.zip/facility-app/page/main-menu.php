<!-- Dashboard Page -->
<div class="container fade-in" id="dashboardPage">
    <div class="header d-flex justify-content-between align-items-center mb-4">
        <h4>
            <i class="bi bi-person-circle"></i> 
            Welcome, <?php echo isset($_SESSION['name']) ? htmlspecialchars($_SESSION['name']) : 'User'; ?> (<?php echo isset($_SESSION['role']) ? htmlspecialchars($_SESSION['role']) : 'Role'; ?>)
        </h4>
        <a href="page/logout.php" class="btn btn-danger">
            <i class="bi bi-box-arrow-right"></i> Logout
        </a>
    </div>
        <div class="mb-4">
            <h4><i class="bi bi-list-task"></i> Summary Tugas</h4>
            <div class="summary-grid" id="summaryList">
                <div class="card summary-card" data-work-order-id="1" onclick="openTask(1, 'Clean', 'Finished')">
                    <div class="card-body">
                        <h5 class="card-title"><i class="bi bi-broom"></i> Work Order #1 - Clean</h5>
                        <p class="card-text">Status: Finished<br>Ruang Meeting, Deep Cleaning</p>
                    </div>
                </div>
                <div class="card summary-card" data-work-order-id="2" onclick="openTask(2, 'Inspection', 'Pending')">
                    <div class="card-body">
                        <h5 class="card-title"><i class="bi bi-check2-square"></i> Work Order #2 - Inspection</h5>
                        <p class="card-text">Status: Pending<br>Lantai 3</p>
                    </div>
                </div>
                <div class="card summary-card" data-work-order-id="3" onclick="openTask(3, 'Clean', 'Pending')">
                    <div class="card-body">
                        <h5 class="card-title"><i class="bi bi-broom"></i> Work Order #3 - Clean</h5>
                        <p class="card-text">Status: Pending<br>Kantin</p>
                    </div>
                </div>
                <div class="card summary-card" data-work-order-id="4" onclick="openTask(4, 'AdHoc', 'Pending')">
                    <div class="card-body">
                        <h5 class="card-title"><i class="bi bi-lightning"></i> Work Order #4 - AdHoc</h5>
                        <p class="card-text">Status: Pending<br>Mengganti lampu</p>
                    </div>
                </div>
            </div>
        </div>
        <button id="openCategoryModalBtn" class="btn btn-primary btn-lg rounded-circle floating-btn" data-bs-toggle="modal" data-bs-target="#categoryModal"><i class="bi bi-plus"></i></button>    </div>

    <!-- Modal untuk Pilih Kategori -->
    <div class="modal fade" id="categoryModal" tabindex="-1" aria-labelledby="categoryModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="categoryModalLabel"><i class="bi bi-list-ul"></i> Pilih Kategori Work Order</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="d-grid gap-2">
                        <button class="btn btn-outline-primary category-btn" onclick="openForm('Clean')"><i class="bi bi-broom"></i> Clean</button>
                        <button class="btn btn-outline-primary category-btn" onclick="openForm('Inspection')"><i class="bi bi-check2-square"></i> Inspection</button>
                        <button class="btn btn-outline-primary category-btn" onclick="openForm('Control')"><i class="bi bi-gear"></i> Control</button>
                        <button class="btn btn-outline-primary category-btn" onclick="openForm('AdHoc')"><i class="bi bi-lightning"></i> AdHoc</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Form untuk Clean -->
    <div class="container d-none fade-in" id="cleanFormPage">
        <h2 class="text-center my-4"><i class="bi bi-broom"></i> Form Clean</h2>
        <form id="cleanForm">
            <input type="hidden" name="work_order_id" id="cleanWorkOrderId">
            <div class="mb-3">
                <label for="clean_location" class="form-label">Lokasi</label>
                <input type="text" class="form-control" id="clean_location" name="location" required>
            </div>
            <div class="mb-3">
                <label for="clean_description" class="form-label">Deskripsi</label>
                <textarea class="form-control" id="clean_description" name="description" rows="4"></textarea>
            </div>
            <div class="mb-3">
                <label for="clean_tools_used" class="form-label">Alat yang Digunakan</label>
                <input type="text" class="form-control" id="clean_tools_used" name="tools_used">
            </div>
            <div class="mb-3">
                <label for="cleaning_type" class="form-label">Tipe Pembersihan</label>
                <select class="form-select" id="cleaning_type" name="cleaning_type" required>
                    <option value="Light">Light</option>
                    <option value="Deep">Deep</option>
                    <option value="Special">Special</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="clean_duration_minutes" class="form-label">Durasi (menit)</label>
                <input type="number" class="form-control" id="clean_duration_minutes" name="duration_minutes">
            </div>
            <div class="mb-3 d-none" id="cleanPhotoBeforeSection">
                <label for="clean_photo_before" class="form-label">Foto Before</label>
                <input type="file" class="form-control" id="clean_photo_before" name="photo_before" accept="image/*">
                <label for="clean_photo_before_note" class="form-label mt-2">Keterangan Foto Before</label>
                <textarea class="form-control" id="clean_photo_before_note" name="photo_before_note" rows="2"></textarea>
            </div>
            <div class="d-flex justify-content-between">
                <button type="button" class="btn btn-secondary" onclick="backToDashboard()"><i class="bi bi-arrow-left"></i> Kembali</button>
                <button type="submit" class="btn btn-primary" name="submit_clean"><i class="bi bi-check2"></i> Lanjutkan</button>
            </div>
            <button type="button" class="btn btn-success finish-task-btn d-none" id="cleanFinishTaskBtn" onclick="openFinishTask('Clean')"><i class="bi bi-check-circle"></i> Selesai Tugas</button>
        </form>
    </div>

    <!-- Form untuk Inspection -->
    <div class="container d-none fade-in" id="inspectionFormPage">
        <h2 class="text-center my-4"><i class="bi bi-check2-square"></i> Form Inspection</h2>
        <form id="inspectionForm">
            <input type="hidden" name="work_order_id" id="inspectionWorkOrderId">
            <div class="mb-3">
                <label for="area_inspected" class="form-label">Area yang Diinspeksi</label>
                <input type="text" class="form-control" id="area_inspected" name="area_inspected" required>
            </div>
            <div class="mb-3">
                <label for="is_clean" class="form-label">Bersih?</label>
                <select class="form-select" id="is_clean" name="is_clean" required>
                    <option value="1">Ya</option>
                    <option value="0">Tidak</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="is_safe" class="form-label">Aman?</label>
                <select class="form-select" id="is_safe" name="is_safe" required>
                    <option value="1">Ya</option>
                    <option value="0">Tidak</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="equipment_condition" class="form-label">Kondisi Peralatan</label>
                <select class="form-select" id="equipment_condition" name="equipment_condition" required>
                    <option value="Good">Baik</option>
                    <option value="NeedsRepair">Perlu Perbaikan</option>
                    <option value="Damaged">Rusak</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="inspection_notes" class="form-label">Catatan</label>
                <textarea class="form-control" id="inspection_notes" name="notes" rows="4"></textarea>
            </div>
            <div class="mb-3 d-none" id="inspectionPhotoBeforeSection">
                <label for="inspection_photo_before" class="form-label">Foto Before</label>
                <input type="file" class="form-control" id="inspection_photo_before" name="photo_before" accept="image/*">
                <label for="inspection_photo_before_note" class="form-label mt-2">Keterangan Foto Before</label>
                <textarea class="form-control" id="inspection_photo_before_note" name="photo_before_note" rows="2"></textarea>
            </div>
            <div class="d-flex justify-content-between">
                <button type="button" class="btn btn-secondary" onclick="backToDashboard()"><i class="bi bi-arrow-left"></i> Kembali</button>
                <button type="submit" class="btn btn-primary" name="submit_inspection"><i class="bi bi-check2"></i> Lanjutkan</button>
            </div>
            <button type="button" class="btn btn-success finish-task-btn d-none" id="inspectionFinishTaskBtn" onclick="openFinishTask('Inspection')"><i class="bi bi-check-circle"></i> Selesai Tugas</button>
        </form>
    </div>

    <!-- Form untuk Control -->
    <div class="container d-none fade-in" id="controlFormPage">
        <h2 class="text-center my-4"><i class="bi bi-gear"></i> Form Control</h2>
        <form id="controlForm">
            <input type="hidden" name="work_order_id" id="controlWorkOrderId">
            <div class="mb-3">
                <label for="system_checked" class="form-label">Sistem yang Diperiksa</label>
                <input type="text" class="form-control" id="system_checked" name="system_checked" required>
            </div>
            <div class="mb-3">
                <label for="status_check" class="form-label">Status</label>
                <select class="form-select" id="status_check" name="status_check" required>
                    <option value="Operational">Operasional</option>
                    <option value="MaintenanceRequired">Perlu Perawatan</option>
                    <option value="OutOfService">Tidak Berfungsi</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="last_maintenance_date" class="form-label">Tanggal Perawatan Terakhir</label>
                <input type="date" class="form-control" id="last_maintenance_date" name="last_maintenance_date">
            </div>
            <div class="mb-3">
                <label for="control_notes" class="form-label">Catatan</label>
                <textarea class="form-control" id="control_notes" name="notes" rows="4"></textarea>
            </div>
            <div class="mb-3 d-none" id="controlPhotoBeforeSection">
                <label for="control_photo_before" class="form-label">Foto Before</label>
                <input type="file" class="form-control" id="control_photo_before" name="photo_before" accept="image/*">
                <label for="control_photo_before_note" class="form-label mt-2">Keterangan Foto Before</label>
                <textarea class="form-control" id="control_photo_before_note" name="photo_before_note" rows="2"></textarea>
            </div>
            <div class="d-flex justify-content-between">
                <button type="button" class="btn btn-secondary" onclick="backToDashboard()"><i class="bi bi-arrow-left"></i> Kembali</button>
                <button type="submit" class="btn btn-primary" name="submit_control"><i class="bi bi-check2"></i> Lanjutkan</button>
            </div>
            <button type="button" class="btn btn-success finish-task-btn d-none" id="controlFinishTaskBtn" onclick="openFinishTask('Control')"><i class="bi bi-check-circle"></i> Selesai Tugas</button>
        </form>
    </div>

    <!-- Form untuk AdHoc -->
    <div class="container d-none fade-in" id="adHocFormPage">
        <h2 class="text-center my-4"><i class="bi bi-lightning"></i> Form AdHoc</h2>
        <form id="adHocForm">
            <input type="hidden" name="work_order_id" id="adHocWorkOrderId">
            <div class="mb-3">
                <label for="adhoc_description" class="form-label">Deskripsi</label>
                <textarea class="form-control" id="adhoc_description" name="description" rows="4" required></textarea>
            </div>
            <div class="mb-3">
                <label for="adhoc_photo_path" class="form-label">Foto (Opsional)</label>
                <input type="file" class="form-control" id="adhoc_photo_path" name="photo_path" accept="image/*">
            </div>
            <div class="mb-3 d-none" id="adHocPhotoBeforeSection">
                <label for="adhoc_photo_before" class="form-label">Foto Before</label>
                <input type="file" class="form-control" id="adhoc_photo_before" name="photo_before" accept="image/*">
                <label for="adhoc_photo_before_note" class="form-label mt-2">Keterangan Foto Before</label>
                <textarea class="form-control" id="adhoc_photo_before_note" name="photo_before_note" rows="2"></textarea>
            </div>
            <div class="d-flex justify-content-between">
                <button type="button" class="btn btn-secondary" onclick="backToDashboard()"><i class="bi bi-arrow-left"></i> Kembali</button>
                <button type="submit" class="btn btn-primary" name="submit_adhoc"><i class="bi bi-check2"></i> Lanjutkan</button>
            </div>
            <button type="button" class="btn btn-success finish-task-btn d-none" id="adHocFinishTaskBtn" onclick="openFinishTask('AdHoc')"><i class="bi bi-check-circle"></i> Selesai Tugas</button>
        </form>
    </div>

    <!-- Modal untuk Upload Photo After -->
    <div class="modal fade" id="finishTaskModal" tabindex="-1" aria-labelledby="finishTaskModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="finishTaskModalLabel"><i class="bi bi-check-circle"></i> Selesai Tugas</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="finishTaskForm">
                        <input type="hidden" name="work_order_id" id="finishWorkOrderId">
                        <div class="mb-3">
                            <label for="photo_after" class="form-label">Upload Foto After</label>
                            <input type="file" class="form-control" id="photo_after" name="photo_after" accept="image/*" required>
                        </div>
                        <div class="mb-3">
                            <label for="photo_after_note" class="form-label">Keterangan Foto After</label>
                            <textarea class="form-control" id="photo_after_note" name="photo_after_note" rows="2"></textarea>
                        </div>
                        <button type="submit" class="btn btn-success w-100"><i class="bi bi-upload"></i> Selesaikan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal untuk Pesan Sukses -->
    <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header" style="background-color: #28a745; border-color: #28a745;">
                    <h5 class="modal-title" id="successModalLabel"><i class="bi bi-check-circle success-icon"></i> Sukses!</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p id="successMessage"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onclick="backToDashboard()">OK</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal untuk Akses Ditolak -->
    <div class="modal fade" id="restrictedModal" tabindex="-1" aria-labelledby="restrictedModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header" style="background-color: #dc3545; border-color: #dc3545;">
                    <h5 class="modal-title" id="restrictedModalLabel"><i class="bi bi-exclamation-circle error-icon"></i> Akses Ditolak</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Tugas AdHoc hanya dapat diakses oleh Staff atau Admin.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/main.js"></script>